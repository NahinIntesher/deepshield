import os
from pathlib import Path
ROOT=Path(os.environ['DEEPSHIELD_ROOT'])
CHECKPOINT_PATH=ROOT/'best_model.pth'
FACE_MODEL_ROOT=ROOT/'face-model'
FACE_PROVIDER='CPUExecutionProvider'
NUM_FRAMES=16
MODEL_NAME='Swin-Small + DCT + Temporal Transformer'
